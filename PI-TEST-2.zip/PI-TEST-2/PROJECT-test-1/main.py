import pygame
import pygame_menu as pm 
from rpm.rpm import RpmGauge
from aux_gauge.AuxGauge import AuxGauge
from draw import *
import sys
import time
import obd
from obd import OBDStatus
from screen_brightness_control import set_brightness
import math

##Global settings for the program 
#BackgroundColour = 'Black'
#CarLogo = 'BMW'

DarkModeActive = False
DisplayBrigness = 60
SettingsUpdated = False
GcoolantTemp = 0
GfuelLevel = 0
GoilPressure = 0
GboostPressure = 0
VIN = ""
EcuName = ""
CarVoltage = 0 
SpeedUnitActive = "MPH"
## Connect to OBD2 Port ##
connection = obd.OBD() # auto connect

#Get car infomation (Uncomment for Fianl)
#Get Car VIN 
getVin = obd.commands.VIN
response = connection.query(getVin) 
VIN = response.value
print(VIN)

#Get Car ECU Name 
#getECU = obd.commands.ECU_NAME
#response = connection.query(getECU) 
#EcuName = response.value
#print(EcuName)

#Get Car Volatge
getCarVolts = obd.commands.ELM_VOLTAGE
response = connection.query(getCarVolts) 
CarVoltage = response.value
print(CarVoltage)


#Testing Car brand logo 
CarBrandLogos = [("BMW", "BMW"), ("Ford", "Ford"), ("Hyundaii", "Hyundaii"), ("Kia", "Kia"), ("Mercedes", "Mercedes"),
                  ("Nissan", "Nissan"), ("Toyota", "Toyota"), ("Vauxhall", "Vauxhall"), ("Volkswagen", "Volkswagen")]

CarBrandLogosSelect = ["BMW", "Ford", "Hyundaii", "Kia", "Mercedes",
                  "Nissan", "Toyota", "Vauxhall", "Volkswagen"]

BackgroundColours = [("Black", "Black"), ("Grey", "Grey"), ("Purple", "Purple"), ("Red", "Red"), ("Tan", "Tan")]

SpeedUnits = [("MPH", ""), ("KPH", "")]
#Sets the defualt background 
ImgURL = "images/Backgrounds/background_Black_MPH.png"
CarMakeLogo = "images/Logos/BMW.png"
MenuButtonImg = "images/ButtonImgs/menuButton.png"

#Warning Icons
CoolantWICON = "images/WarningLights/coolantLight.png"
OilWIcon = "images/WarningLights/oilPressure.png"
TurboWIcon = "images/WarningLights/turboWarn.png"
FuelWIcon = "images/WarningLights/fuelLow.png"

# Setup Display
pygame.init()
WIDTH, HEIGHT = 1024,732 # real dispay 1024, 600  # use your screens display information
WIN = pygame.display.set_mode((WIDTH, HEIGHT)) #((WIDTH, HEIGHT), pygame.FULLSCREEN) 

##Test Full screen on PI (Comment above line and decomment below)
#WIN = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)


FPS = 60

# Icons and BG #
ICON = "images/speedometer.png"
BACKGROUND = pygame.image.load(ImgURL).convert_alpha()
MenuButtonPY = pygame.image.load(MenuButtonImg).convert_alpha()
MenuButtonPY = pygame.transform.scale(MenuButtonPY, (175,175))
Menurect = MenuButtonPY.get_rect(center=(1800, 100))
CarMake = pygame.image.load(CarMakeLogo).convert_alpha()
CarMake = pygame.transform.scale(CarMake, (200, 150))
BACKGROUNDUpdated = ""
CarMakeUpdated = ""

#Warnings 
CoolantWarning = pygame.image.load(CoolantWICON).convert_alpha()
OilPressureWarning = pygame.image.load(OilWIcon).convert_alpha()
TurboBoostWarning = pygame.image.load(TurboWIcon).convert_alpha()
FuelWarning = pygame.image.load(FuelWIcon).convert_alpha()
CoolantWarning = pygame.transform.scale(CoolantWarning, (50, 70))
OilPressureWarning = pygame.transform.scale(OilPressureWarning, (50, 70))
TurboBoostWarning = pygame.transform.scale(TurboBoostWarning, (50, 70))
FuelWarning = pygame.transform.scale(FuelWarning, (50, 70))

# Font
FONT_PATH1 = "fonts/DSEG7Classic-Bold.ttf"
FONT_PATH2 = "fonts/DSEG14Classic-Regular.ttf" 
FONT_LARGE = 240    #   Speedo size
FONT_Menu = 64
font_Connection = 30
font_speedunits = pygame.font.Font(FONT_PATH1, FONT_LARGE)
font_menu_text  = pygame.font.Font(FONT_PATH2, FONT_Menu)
font_Connection  = pygame.font.Font(FONT_PATH2,font_Connection )


## Set Gauge positions 

RPM_XY = (25, 100)
COOLANT_XY = (780, 360)
FUEL_XY = (840, 360)
OILPRESSURE_XY = (900, 360)
BOOST_XY = (960, 360)
SPEEDO_XY = (680, 550)
 
#   Create gauge instances from classes.
boost = AuxGauge(BOOST_XY, 19)
fuellevel = AuxGauge(FUEL_XY, 19)
coolant = AuxGauge(COOLANT_XY, 19)
oilpressure = AuxGauge(OILPRESSURE_XY, 19)
rpm = RpmGauge(RPM_XY, 50)


#   Colours
NEON_YELLOW = (236, 253, 147)   #   Speedo Colour
#NEON_GREEN = (145, 213, 89)     #   Lower gauge colours, clock, odo etc
DARK_GREY = (9, 52, 50)         #   background of the digits (for the 7segment appearance)
RED = (255, 0, 0) 
GREEN = (0, 255, 0) 
BLUE = (0, 0, 255) 
CYAN = (0, 100, 100) 
BLACK = (0, 0, 0) 
WHITE = (255, 255, 255) 

## Get data values from obd ##

def Get_rpm():
    RPM = obd.commands.RPM
    rpm_obd = connection.query(RPM)
    GRpm = rpm_obd.value.magnitude
    print(GRpm)
    RpmRawValue = GRpm # rpm_obd.value
    #rpm.set_frame(rpm_obd)
    rpm.set_frame(roundup(RpmRawValue))
 

def Get_coolant_Temp():
    global coolantTemp
    Ctemp = obd.commands.COOLANT_TEMP
    coolant_obd =  connection.query(Ctemp)
    GcoolantTemp = coolant_obd.value.magnitude
    print(GcoolantTemp)
    coolantRawValue = GcoolantTemp / 10  * 18 / 10#  coolant_obd.value
    coolant.set_frame(round(coolantRawValue))


def Get_fuellevel():
    FLevel =  obd.commands.FUEL_LEVEL
    fuellevel_obd = connection.query(FLevel)
    GfuelLevel = fuellevel_obd.value.magnitude
    print(GfuelLevel)
    fuellevelRawValue = GfuelLevel / 10 * 18 / 10#  
    fuellevel.set_frame(round(fuellevelRawValue))



def Get_oilpressure():
    Opressure =  obd.commands.OIL_TEMP
    oilpressure_obd = connection.query(Opressure)
    #GoilPressure = oilpressure_obd.value.magnitude
    #print(GoilPressure)
    #oilpressureRawValue = GoilPressure / 10  * 19 / 10#  
    #oilpressure.set_frame(round(oilpressureRawValue))
 



def Get_boost():
    print("")
   # Blevel =  obd.commands.INTAKE_PRESSURE
   # boost_obd = connection.query(Blevel)
   # GboostPressure = boost_obd.value.magnitude
   # print(GboostPressure)
   # boostRawValue = GboostPressure / 10  * 19 / 10#  
   # boost.set_frame(round(boostRawValue))


def Get_Car_Speed():
    global speed_status
    global SpeedUnitActive
    Cspeed = obd.commands.SPEED 
    if SpeedUnitActive == 'MPH':

        car_speed = obd.commands.SPEED 
        car_speed = connection.query(Cspeed)
        Raw_speed_status = car_speed.value.magnitude
        MPH_speed = Raw_speed_status * 0.6213
        speed_status = round(MPH_speed)
    else: 
        car_speed = obd.commands.SPEED
        car_speed = connection.query(Cspeed) 
        speed_status = car_speed.value.magnitude
    
   # speed_status = 99
    
    draw_speedometer_text()
    pygame.display.update()


######
#       Various Functions for Dash
######


def UpdateDisplay(BackgroundColour, CarLogo, SpeedUnit, DisplayBrigness):
    global SettingsUpdated
    global BACKGROUNDUpdated
    global CarMakeUpdated
    global SpeedUnitActive
    if SpeedUnit == 'KPH':
        ImgURLUpdate = "images/Backgrounds/background_" + BackgroundColour + "_KPH.png"
        SpeedUnitActive = "KPH"
    else:
         ImgURLUpdate = "images/Backgrounds/background_" + BackgroundColour + "_MPH.png"
         SpeedUnitActive = "MPH"

    ## Used to scale each image and ensure that it fits correctly on the screen
    CarMakeLogoUpdated = "images/Logos/" + CarLogo + ".png"
    CarBrandLogosSelect = ["BMW", "Ford", "Hyundaii", "Kia", "Mercedes",
                  "Nissan", "Toyota", "Vauxhall", "Volkswagen"]
    BACKGROUNDUpdated = pygame.image.load(ImgURLUpdate).convert_alpha()
    CarMakeUpdated = pygame.image.load(CarMakeLogoUpdated).convert_alpha()
    if CarLogo == "Kia" or "Mercedes" or "Ford":
        CarMakeUpdated = pygame.transform.scale(CarMakeUpdated, (175,120))
    elif CarLogo == "Nissan":
        CarMakeUpdated = pygame.transform.scale(CarMakeUpdated, (150, 120))
    elif CarLogo == "Toyota":
        CarMakeUpdated = pygame.transform.scale(CarMakeUpdated, (300, 200))
    elif CarLogo == "Vauxhall" or "Volkswagen":
        CarMakeUpdated = pygame.transform.scale(CarMakeUpdated, (250, 200))
    elif CarLogo == "BMW":
        CarMakeUpdated = pygame.transform.scale(CarMakeUpdated, (250, 100))
    else:
        CarMakeUpdated = pygame.transform.scale(CarMakeUpdated, (250, 200))

    set_brightness(DisplayBrigness)



    SettingsUpdated = True


def draw_speedometer_text():
    '''
    Speedometer text and write
    '''
    #global speed_status
    #global font_speedunits
    speedtext = font_speedunits.render(str(speed_status), True, NEON_YELLOW)
    text_rect = speedtext.get_rect()
    text_rect.midright = SPEEDO_XY
    WIN.blit(speedtext, text_rect)



#####
#       Main Function for the Pygame Program
#####




def main():
    global GcoolantTemp
    global GfuelLevel
    global GoilPressure
    global GboostPressure

    run = True
    while run:
        # for event in pygame.event.get():
        #     if event.type == pygame.MOUSEBUTTONDOWN:
        #         optionsPage()
        if GcoolantTemp <= 100:
            WIN.blit(CoolantWarning, (780,285)) 
        if GfuelLevel <= 100:
            WIN.blit(FuelWarning, (840,285)) 
        if GoilPressure <= 100:
            WIN.blit(OilPressureWarning, (900,285)) 
        if GboostPressure <= 100:
            WIN.blit(TurboBoostWarning, (960,285)) 
        


        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False

            UpdateData()
            CarGuages()

        
    

          
if __name__ == "__main__":
    main()

def roundup(x):
    return int(math.ceil(x / 100.0)) * 100

def UpdateData():
    Get_rpm()
    Get_coolant_Temp()
    Get_fuellevel()
    Get_boost()
    Get_oilpressure()
    Get_Car_Speed()
    pygame.display.update()
    
   

    

def CarGuages():
    global BACKGROUNDUpdated
    global CarMakeUpdated
    while True:
        
       

        guages = pm.Menu(title="Settings", 
                       width=WIDTH, 
                       height=HEIGHT) 
        if SettingsUpdated == True:
            WIN.blit(BACKGROUNDUpdated, (0, 0))
            WIN.blit(CarMakeUpdated, (20, 20))
        else:
            WIN.blit(BACKGROUND, (0, 0))
            WIN.blit(CarMake, (20, 20))
            WIN.blit(MenuButtonPY, (1800,100)) 
        rpm.show(WIN)
        coolant.show(WIN)
        boost.show(WIN)
        oilpressure.show(WIN)
        fuellevel.show(WIN)
        
        if OBDStatus.NOT_CONNECTED:
            ConnectionText = font_Connection.render('OBD2 Not Connected', True, WHITE, BLACK)
            WIN.blit(ConnectionText, (300,10)) 
        
        # for event in pygame.event.get():
        #     UpdateData()
        #     if event.type == pygame.MOUSEBUTTONDOWN:
        #         optionsPage()



        pygame.display.update()

        break
        
                



def optionsPage():

    def UpdateSettings(): 
        global VIN
        global EcuName
        global CarVoltage

        #BackgroundColourUS = 'Black'
        #CarLogoUS = 'BMW'
        # getting the data using "get_input_data" method of the Menu class 
       # global DarkModeActive
        BackgroundColour = 'Black'
        CarLogo = 'BMW'
        SpeedUnit = 'MPH'
        settingsData = settings.get_input_data() 
  
        for key in settingsData.keys(): 
            #View data in settings 
            #print({key})
           # print(f"{key}\t:\t{settingsData[key]}") 

            if key == 'brightness':
                DisplayBrigness = settingsData[key]

          # if key == 'DarkMode':
           #     DarkModeActive = settingsData[key]

            if key == 'SpeedUnit':
                for unit in settingsData[key]:
                    if unit == 0: 
                        SpeedUnit = 'MPH'
                    elif unit == 1:
                        SpeedUnit = 'KPH'

            if key == 'CarBrandLogo':
                for brand in settingsData[key]:
                    if brand == 0:
                        CarLogo = 'BMW'
                    elif brand == 1:
                        CarLogo = 'Ford'
                    elif brand == 2:
                        CarLogo = 'Hyundaii'
                    elif brand == 3:
                        CarLogo = 'Kia'
                    elif brand == 4:
                        CarLogo = 'Mercedes'
                    elif brand == 5:
                        CarLogoUS = 'Nissan'
                    elif brand == 6:
                        CarLogo = 'Toyota'
                    elif brand == 7:
                        CarLogo = 'Vauxhall'
                    elif brand == 8:
                        CarLogo = 'Volkswagen'

            if key == 'BackgroundColour':
                for colour in settingsData[key]:
                    if colour == 0:
                        BackgroundColour = 'Black'
                    elif colour == 1:
                        BackgroundColour = 'Grey'
                    elif colour == 2:
                        BackgroundColour = 'Purple'
                    elif colour == 3:
                        BackgroundColour = 'Red'
                    elif colour == 4:
                        BackgroundColour = 'Tan'



            

        
        
        UpdateDisplay(BackgroundColour, CarLogo, SpeedUnit, DisplayBrigness)
        print('\nSettings selected: ')
        print('Selected car logo is: ' + CarLogo)
        print("Selected Brightness of Display is: " + str(DisplayBrigness))
        print('Is Dark mode active: ' + str(DarkModeActive))
        print('Selected speed unit is: ' + SpeedUnit)
        print('Selected background colour is: ' + BackgroundColour)

        

        


    while True:
        tColor=(0,0,0,0)
        OPTIONS_MOUSE_POS = pygame.mouse.get_pos()
        DarkMode = False
        CarVIN =  VIN
        CarECU =  EcuName
        CarVolts = CarVoltage

        settings = pm.Menu(title="Settings", 
                       width=WIDTH, 
                       height=HEIGHT) 

        
        settings._theme.widget_font_size = 25
        settings._theme.widget_font_color = BLACK 
        settings._theme.widget_alignment = pm.locals.ALIGN_LEFT 
        settings._theme.selection_color = tColor


        

        #Display ECU Model 
        #(Add) "ECU Model Name: " + obd.commands.ECU_NAME + "\nVehicle VIN: " + obd.commands.VIN 
        settings.add.label(title="Vechicle VIN: " + CarVIN )
        settings.add.label(title="ECU Model Number: " + CarECU ) 
        settings.add.label(title="Car Voltage: " + CarVolts ) 

        #Backround Colour (Drop down old-style)
        #settings.add.dropselect(title="Background Colour", items=BackgroundColours, 
        #    dropselect_id="BackgroundColour", default=0)
            
        settings.add.selector(title="Background Colour", items=BackgroundColours, 
                          default=0, style="fancy", selector_id="BackgroundColour")    
        
        #Car Logo Colour (Drop down old-style)
     #   settings.add.dropselect(title="Car Logo", items=CarBrandLogos, 
      #       dropselect_id="CarBrandLogo", default=0)
        
        settings.add.selector(title="Car Logo", items=CarBrandLogos, 
                        default=0, style="fancy", selector_id="CarBrandLogo")    
        
        #Dark Mode (Not implemented Yet)
      #  settings.add.toggle_switch(title="Dark Mode", default=False, toggleswitch_id="DarkMode") 

        #Brightness Slider 
        settings.add.range_slider(title="Brightness", default=60, range_values=( 
            0, 100), increment=1, value_format=lambda x: str(int(x)), rangeslider_id="brightness") 

        
        

        #Speed Unit 
        settings.add.selector(title="Speed Unit", items=SpeedUnits, 
                          default=0, style="fancy", selector_id="SpeedUnit")         
        settings.add.button(title="Update Settings", action= UpdateSettings , 
                        font_color=WHITE, background_color=GREEN) 
        settings.add.button(title="Restore Defaults", action=settings.reset_value, 
                        font_color=WHITE, background_color=RED) 
        settings.add.button(title="Return To Dash", 
                        action=CarGuages, align=pm.locals.ALIGN_CENTER) 
        settings.add.button(title="Exit Application",                   ##Temp used to exit 
                        action=exit, align=pm.locals.ALIGN_CENTER)                 
  

        #Using the settings 
        settingsDataStre = settings.get_input_data() 
      #  print(settingsDataStre.keys({'BackgroundColour'}))
     #   if BackgroundColours == (('Black', '')):
      #      print("aaaa")
        
        
        settings.mainloop(WIN) 
                
        
        pygame.display.update()
       




