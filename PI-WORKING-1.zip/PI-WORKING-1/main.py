import pygame
from rpm.rpm import RpmGauge
from aux_gauge.AuxGauge import AuxGauge
from draw import *
#import sys
import time
import obd
from obd import OBDStatus
from screen_brightness_control import set_brightness
import math
import pygame_menu as pm 

#######################################
#######################################
#######################################
##** UNCOMMENT any  #! FOR PI FINAL**##  
####** UNCOMMENT #& FOR TESTING **#####
#######################################
#######################################
#######################################



#Global settings used within the program 
DarkModeActive = False
DisplayBrigness = 60
SettingsUpdated = False
VIN = ""
EcuName = ""
CarVoltage = 0 
SpeedUnitActive = "MPH"
speed_status = 0
OBS_Not_Connected = True

try:
    time.sleep(10)
    connection = obd.OBD() # auto-connects to USB or RF port
    OBS_Not_Connected = False
except:
    print("No ODB Port Connection")
    OBS_Not_Connected = True

  

##########
##Gets Car VIN 
##########
try:
    getVin = obd.commands.VIN
    response = connection.query(getVin) 
    VIN = str(response.value)
    #&VIN = "1323457"
    print(VIN)
except: 
    print("Error with Car VIN using defualt test")
    VIN = "1323457"  
    print(VIN)  

##########
##Gets Car ECU Name (WORK IN PROGRESS)
###########
#getECU = obd.commands.ECU_NAME
#response = connection.query(cmd) 
#EcuName = str(response.value)
#EcuName = 'Tom' # response.value
#print(EcuName)

##########
##Gets Car Volatge
##########
try:
    getCarVolts = obd.commands.ELM_VOLTAGE
    response = connection.query(getCarVolts) 
    CarVoltage = str(response.value)
    print(CarVoltage)
    #&CarVoltage = "12.7"
except: 
    print("Error with Car Volts using defualt test")    
    CarVoltage = "12.7"
    print(CarVoltage)


##########
##Used in the settings page to show the user a list of chamngable options 
##########
CarBrandLogos = [("BMW", "BMW"), ("Ford", "Ford"), ("Hyundaii", "Hyundaii"), ("Kia", "Kia"), ("Mercedes", "Mercedes"),
                  ("Nissan", "Nissan"), ("Toyota", "Toyota"), ("Vauxhall", "Vauxhall"), ("Volkswagen", "Volkswagen")]

CarBrandLogosSelect = ["BMW", "Ford", "Hyundaii", "Kia", "Mercedes",
                  "Nissan", "Toyota", "Vauxhall", "Volkswagen"]

BackgroundColours = [("Black", "Black"), ("Grey", "Grey"), ("Purple", "Purple"), ("Red", "Red"), ("Tan", "Tan")]

SpeedUnits = [("MPH", ""), ("KPH", "")]


##########
##Sets the path for each of the images that need to be loaded
##########
ImgURL = "images/Backgrounds/background_Black_MPH.png"
CarMakeLogo = "images/Logos/BMW.png"
MenuButtonImg = "images/ButtonImgs/menuButton.png"
CoolantWICON = "images/WarningLights/coolantLight.png"
OilWIcon = "images/WarningLights/oilPressure.png"
TurboWIcon = "images/WarningLights/turboWarn.png"
FuelWIcon = "images/WarningLights/fuelLow.png"

##########
##Sets the display to the required resolution, makes it full screen and sets the FPS to 60 
##########
pygame.init()
WIDTH, HEIGHT = 1024,732 #Sceens Resolution 

if OBS_Not_Connected:
    WIN = pygame.display.set_mode((WIDTH, HEIGHT)) 
else:
    WIN = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)

FPS = 60

##########
##Loads the car make logo and the background then resizes them ready for later use
##########
ICON = "images/speedometer.png"
BACKGROUND = pygame.image.load(ImgURL).convert_alpha()
MenuButtonPY = pygame.image.load(MenuButtonImg).convert_alpha()
MenuButtonPY = pygame.transform.scale(MenuButtonPY, (175,175))
Menurect = MenuButtonPY.get_rect(center=(1800, 100))
CarMake = pygame.image.load(CarMakeLogo).convert_alpha()
CarMake = pygame.transform.scale(CarMake, (200, 150))
BACKGROUNDUpdated = ""
CarMakeUpdated = ""

##########
##Loads each of the warning images then resizes them ready for later use
##########
CoolantWarning = pygame.image.load(CoolantWICON).convert_alpha()
OilPressureWarning = pygame.image.load(OilWIcon).convert_alpha()
TurboBoostWarning = pygame.image.load(TurboWIcon).convert_alpha()
FuelWarning = pygame.image.load(FuelWIcon).convert_alpha()
CoolantWarning = pygame.transform.scale(CoolantWarning, (50, 70))
OilPressureWarning = pygame.transform.scale(OilPressureWarning, (50, 70))
TurboBoostWarning = pygame.transform.scale(TurboBoostWarning, (50, 70))
FuelWarning = pygame.transform.scale(FuelWarning, (50, 70))

##########
##Sets each font type for specific parts of the program and inports the fonts to be used
##########
FONT_PATH1 = "fonts/DSEG7Classic-Bold.ttf"
FONT_PATH2 = "fonts/DSEG14Classic-Regular.ttf" 
FONT_LARGE = 240    #   Speedo size
FONT_Menu = 64
font_Connection = 30
font_speedunits = pygame.font.Font(FONT_PATH1, FONT_LARGE)
font_menu_text  = pygame.font.Font(FONT_PATH2, FONT_Menu)
font_Connection  = pygame.font.Font(FONT_PATH2,font_Connection )


##########
##Defines where each guage will be positioned on the screen
##########
RPM_XY = (25, 100)
COOLANT_XY = (780, 360)
FUEL_XY = (840, 360)
OILPRESSURE_XY = (900, 360)
BOOST_XY = (960, 360)
SPEEDO_XY = (680, 550)

##########
##Creates each guage from the class using the X/Y provided
##########
boost = AuxGauge(BOOST_XY, 19)
fuellevel = AuxGauge(FUEL_XY, 19)
coolant = AuxGauge(COOLANT_XY, 19)
oilpressure = AuxGauge(OILPRESSURE_XY, 19)
rpm = RpmGauge(RPM_XY, 50)

##########
##Lists all the avlible colours so they can be used everywhere in the program
##########
NEON_YELLOW = (236, 253, 147)   
#NEON_GREEN = (145, 213, 89)    
DARK_GREY = (9, 52, 50)      
RED = (255, 0, 0) 
GREEN = (0, 255, 0) 
BLUE = (0, 0, 255) 
CYAN = (0, 100, 100) 
BLACK = (0, 0, 0) 
WHITE = (255, 255, 255) 

## Get data values from obd ##

##########
##Function used to get the RPM of the engine from the OBD port/car 
##########
def Get_rpm():
    try:
        RPM = obd.commands.RPM
        rpm_obd = connection.query(RPM)
        GRpm = rpm_obd.value.magnitude
        print(GRpm)
        RpmRawValue = GRpm # rpm_obd.value
        rpm.set_frame(roundup(RpmRawValue))
        pygame.display.update()
    except:
        print("Error with RPM using defualt test")
        rpm_obd = 500
        rpm.set_frame(roundup(rpm_obd))
        pygame.display.update()

    #&rpm_obd = 500 #connection.query(RPM)
    #&RpmRawValue = 500 #rpm_obd # rpm_obd.value
    #&rpm.set_frame(rpm_obd)
    #&rpm.set_frame(roundup(RpmRawValue))
    #&pygame.display.update()
 
##########
##Function used to get the Coolant tempreture from the OBD port/car 
##########
def Get_coolant_Temp():
    CoolantOverheat = False
    try:
        Ctemp = obd.commands.COOLANT_TEMP
        coolant_obd =  connection.query(Ctemp)
        GcoolantTemp = coolant_obd.value.magnitude
        print(GcoolantTemp)
        coolantRawValue = GcoolantTemp / 10  * 14 / 10 #Allows the value to fit into the guage which contains a set amount of segments 
        if coolantRawValue >= 19:           #Stops an error occoring if data is outside the guages limit then itll defualt to max value
            coolantRawValue = 19
        if coolantRawValue >= 16:
            CoolantOverheat = True
        WarningLightCheck(CoolantOverheat, "Coolant")
        coolant.set_frame(round(coolantRawValue))
        pygame.display.update()
    except:
        print("Error with Collant Temp using defualt test")
        GcoolantTemp = 135
        coolantRawValue = GcoolantTemp / 10  * 14 / 10# 
        if coolantRawValue >= 19:           #Stops an error occoring if data is outside the guages limit then itll defualt to max value
            coolantRawValue = 19
        if coolantRawValue >= 16:
            CoolantOverheat = True
        WarningLightCheck(CoolantOverheat, "Coolant")
        coolant.set_frame(round(coolantRawValue))
        pygame.display.update()



##########
##Function used to get the Fuel level from the OBD port/car 
##########
def Get_fuellevel():

    FuelLow = False 

    try:
        FLevel =  obd.commands.FUEL_LEVEL
        fuellevel_obd = connection.query(FLevel)
        GfuelLevel = fuellevel_obd.value.magnitude
        print(GfuelLevel)
        fuellevelRawValue = GfuelLevel / 10 * 18 / 10#  
        if fuellevelRawValue >= 3:
                FuelLow = True
        WarningLightCheck(FuelLow, "Fuel")
        fuellevel.set_frame(round(fuellevelRawValue))
        pygame.display.update()
    except:
        print("Error with Fuel Level using defualt test")
        GfuelLevel = 15
        fuellevelRawValue = GfuelLevel / 10  * 18 / 10
        if fuellevelRawValue >= 3:
            FuelLow = True
        WarningLightCheck(FuelLow, "Fuel")
        fuellevel.set_frame(round(fuellevelRawValue))
        pygame.display.update()


##########
##Function used to get the Oil pressure from the OBD port/car 
##########
def Get_oilpressure():

    OilPressureHigh = False

       
    
    try:
        Opressure =  obd.commands.INTAKE_TEMP
        oilpressure_obd = connection.query(Opressure)
        GoilPressure = oilpressure_obd.value.magnitude
        print(GoilPressure)
        oilpressureRawValue = GoilPressure / 10  * 39 / 10#  
        if oilpressureRawValue <= 18:
            OilPressureHigh = True
        WarningLightCheck(OilPressureHigh, "Oil")
        oilpressure.set_frame(round(oilpressureRawValue))
        pygame.display.update()
    except:
         print("Error with Oil Pressure using defualt test")
         GoilPressure = 95
         oilpressureRawValue = GoilPressure / 10  * 18 / 10# 
         if oilpressureRawValue <= 18:
            OilPressureHigh = True
         WarningLightCheck(OilPressureHigh, "Oil")
         oilpressure.set_frame(round(oilpressureRawValue))
         pygame.display.update()
 


##########
##Function used to get the Boost/Intake pressure from the OBD port/car  
##########
def Get_boost():
    
    OverBoost = False 

        
    try:
        Blevel =  obd.commands.INTAKE_PRESSURE
        boost_obd = connection.query(Blevel)
        GBoostPressure = boost_obd.value.magnitude
        print(GBoostPressure)
        boostRawValue = GBoostPressure / 10  * 25 / 10#  
        if boostRawValue >= 16:
            OverBoost = True
        if boostRawValue >= 19:
            boostRawValue = 19
        WarningLightCheck(OverBoost, "Boost")
        boost.set_frame(round(boostRawValue))
        pygame.display.update()
    except:
        print("Error with Boost Pressure using defualt test")
        GBoostPressure = 40
        boostRawValue = GBoostPressure / 10  * 18 / 10# 
        if boostRawValue >= 16:
            OverBoost = True
        if boostRawValue >= 19:
            boostRawValue = 19
        WarningLightCheck(OverBoost, "Boost")
        boost.set_frame(round(boostRawValue))
        pygame.display.update()



##########
##Function used to get the cars speed from the OBD port/car 
##########
def Get_Car_Speed():
    global speed_status
    global SpeedUnitActive
    Cspeed = obd.commands.SPEED 
    if SpeedUnitActive == 'MPH':
        try:
            Cspeed = obd.commands.SPEED 
            car_speed = connection.query(Cspeed)
            Raw_speed_status = car_speed.value.magnitude
            MPH_speed = Raw_speed_status * 0.6213
            speed_status = round(MPH_speed)
            print("Speed is ")
            print(speed_status)
        except:
            print("Error with Speed (MPH) using defualt test")
            car_speed =  45 
    elif SpeedUnitActive == 'KPH': 
        try:
            Cspeed = obd.commands.SPEED
            car_speed = connection.query(Cspeed) 
            speed_status = round(car_speed.value.magnitude)
        except:
            print("Error with Speed (KPH) using defualt test")
            car_speed =  45 
    
   # speed_status = car_speed 
    draw_speedometer_text()




##########
##Function used to update the display with new backrounds, logos and speeed units
##########
def UpdateDisplay(BackgroundColour, CarLogo, SpeedUnit, DisplayBrigness):
    global SettingsUpdated
    global BACKGROUNDUpdated
    global CarMakeUpdated
    global SpeedUnitActive
    if SpeedUnit == 'KPH':
        ImgURLUpdate = "images/Backgrounds/background_" + BackgroundColour + "_KPH.png"
        SpeedUnitActive = "KPH"
    else:
         ImgURLUpdate = "images/Backgrounds/background_" + BackgroundColour + "_MPH.png"
         SpeedUnitActive = "MPH"

    ## Used to scale each image and ensure that it fits correctly on the screen
    CarMakeLogoUpdated = "images/Logos/" + CarLogo + ".png"
    CarBrandLogosSelect = ["BMW", "Ford", "Hyundaii", "Kia", "Mercedes",
                  "Nissan", "Toyota", "Vauxhall", "Volkswagen"]
    BACKGROUNDUpdated = pygame.image.load(ImgURLUpdate).convert_alpha()
    CarMakeUpdated = pygame.image.load(CarMakeLogoUpdated).convert_alpha()
    if CarLogo == "Kia" or "Mercedes" or "Ford":
        CarMakeUpdated = pygame.transform.scale(CarMakeUpdated, (175,120))
    elif CarLogo == "Nissan":
        CarMakeUpdated = pygame.transform.scale(CarMakeUpdated, (150, 120))
    elif CarLogo == "Toyota":
        CarMakeUpdated = pygame.transform.scale(CarMakeUpdated, (300, 200))
    elif CarLogo == "Vauxhall" or "Volkswagen":
        CarMakeUpdated = pygame.transform.scale(CarMakeUpdated, (250, 200))
    elif CarLogo == "BMW":
        CarMakeUpdated = pygame.transform.scale(CarMakeUpdated, (250, 100))
    else:
        CarMakeUpdated = pygame.transform.scale(CarMakeUpdated, (250, 200))

    set_brightness(DisplayBrigness)



    SettingsUpdated = True


##########
##Function used to draw the current speed onto the display 
##########
def draw_speedometer_text():
    '''
    Speedometer text and write
    '''
    global speed_status
    #global font_speedunits
    print(speed_status)
    speedtext = font_speedunits.render(str(speed_status), True, NEON_YELLOW)
    text_rect = speedtext.get_rect()
    text_rect.midright = SPEEDO_XY
    WIN.blit(speedtext, text_rect)





##########
##Function used to check each of the parameters to see if they are over the specifyed limit and if so show a warning symbol 
##########
def WarningLightCheck(value, value_type):
    if  value_type == "Coolant":
        if value == True:
                WIN.blit(CoolantWarning, (780,285)) 
    elif value_type == "Fuel":
        if value == True:
                WIN.blit(FuelWarning, (840,285)) 
    elif value_type == "Oil":
        if value == True:
                WIN.blit(OilPressureWarning, (900,285)) 
    elif value_type == "Boost":
        if value == True:
                WIN.blit(TurboBoostWarning, (960,285)) 

##########
##Function used to check for decimal places and round to the next whole number
##########
def roundup(x):
    return int(math.ceil(x / 100.0)) * 100

##########
##Function repete each of the get data functions to get the latest data 
##########
def UpdateData():
    Get_rpm()
    Get_coolant_Temp()
    Get_fuellevel()
    Get_boost()
    Get_oilpressure()
    Get_Car_Speed()
    pygame.display.update()
    
   
##########
##Function used to display the car guages 
##########
def CarGuages():
    global BACKGROUNDUpdated
    global CarMakeUpdated
    while True:
        
       

        guages = pm.Menu(title="Guages", 
                       width=WIDTH, 
                       height=HEIGHT) 
        if SettingsUpdated == True:
            WIN.blit(BACKGROUNDUpdated, (0, 0))
            WIN.blit(CarMakeUpdated, (20, 20))
        else:
            WIN.blit(BACKGROUND, (0, 0))
            WIN.blit(CarMake, (20, 20))
            WIN.blit(MenuButtonPY, (1800,100)) 
        rpm.show(WIN)
        coolant.show(WIN)
        boost.show(WIN)
        oilpressure.show(WIN)
        fuellevel.show(WIN)
    
        break
        
                


##########
##Function used to display the settings page 
##########
def optionsPage():

    def UpdateSettings(): 
        global VIN
        global EcuName
        global CarVoltage

        #BackgroundColourUS = 'Black'
        #CarLogoUS = 'BMW'
        # getting the data using "get_input_data" method of the Menu class 
       # global DarkModeActive
        BackgroundColour = 'Black'
        CarLogo = 'BMW'
        SpeedUnit = 'MPH'
        settingsData = settings.get_input_data() 
  
        for key in settingsData.keys(): 
            #View data in settings 
            #print({key})
           # print(f"{key}\t:\t{settingsData[key]}") 

            if key == 'brightness':
                DisplayBrigness = settingsData[key]

          # if key == 'DarkMode':
           #     DarkModeActive = settingsData[key]

            if key == 'SpeedUnit':
                for unit in settingsData[key]:
                    if unit == 0: 
                        SpeedUnit = 'MPH'
                    elif unit == 1:
                        SpeedUnit = 'KPH'

            if key == 'CarBrandLogo':
                for brand in settingsData[key]:
                    if brand == 0:
                        CarLogo = 'BMW'
                    elif brand == 1:
                        CarLogo = 'Ford'
                    elif brand == 2:
                        CarLogo = 'Hyundaii'
                    elif brand == 3:
                        CarLogo = 'Kia'
                    elif brand == 4:
                        CarLogo = 'Mercedes'
                    elif brand == 5:
                        CarLogoUS = 'Nissan'
                    elif brand == 6:
                        CarLogo = 'Toyota'
                    elif brand == 7:
                        CarLogo = 'Vauxhall'
                    elif brand == 8:
                        CarLogo = 'Volkswagen'

            if key == 'BackgroundColour':
                for colour in settingsData[key]:
                    if colour == 0:
                        BackgroundColour = 'Black'
                    elif colour == 1:
                        BackgroundColour = 'Grey'
                    elif colour == 2:
                        BackgroundColour = 'Purple'
                    elif colour == 3:
                        BackgroundColour = 'Red'
                    elif colour == 4:
                        BackgroundColour = 'Tan'



            

        
        
        UpdateDisplay(BackgroundColour, CarLogo, SpeedUnit, DisplayBrigness)
        print('\nSettings selected: ')
        print('Selected car logo is: ' + CarLogo)
        print("Selected Brightness of Display is: " + str(DisplayBrigness))
        print('Is Dark mode active: ' + str(DarkModeActive))
        print('Selected speed unit is: ' + SpeedUnit)
        print('Selected background colour is: ' + BackgroundColour)

        

        


    while True:
        tColor=(0,0,0,0)
        OPTIONS_MOUSE_POS = pygame.mouse.get_pos()
     #   DarkMode = False
        CarVIN =  VIN
        CarECU =  EcuName
        CarVolts = CarVoltage

        settings = pm.Menu(title="Settings", 
                       width=WIDTH, 
                       height=HEIGHT) 

     
        settings._theme.widget_font_size = 40
        settings._theme.widget_font_color = BLACK 
        settings._theme.widget_alignment = pm.locals.ALIGN_CENTER
        settings._theme.selection_color = tColor


        

        #Display ECU Model 
        #(Add) "ECU Model Name: " + obd.commands.ECU_NAME + "\nVehicle VIN: " + obd.commands.VIN 
        settings.add.label(align=pm.locals.ALIGN_CENTER, title="Vechicle VIN: " + CarVIN )
        settings.add.label(align=pm.locals.ALIGN_CENTER, title="ECU Model Number: " + CarECU ) 
        settings.add.label(align=pm.locals.ALIGN_CENTER, title="Car Voltage: " + CarVolts) 
            
        settings.add.selector(title="Background Colour", items=BackgroundColours, align=pm.locals.ALIGN_CENTER,
                          default=0, style="fancy", selector_id="BackgroundColour")    
        
        settings.add.selector(title="Car Logo", items=CarBrandLogos,align=pm.locals.ALIGN_CENTER, 
                        default=0, style="fancy", selector_id="CarBrandLogo" )    
        
        #Dark Mode (Not implemented Yet)
      #  settings.add.toggle_switch(title="Dark Mode", default=False, toggleswitch_id="DarkMode") 

        #Brightness Slider 
        settings.add.range_slider(align=pm.locals.ALIGN_CENTER, title="Brightness", default=60, range_values=( 
            0, 100), increment=1, value_format=lambda x: str(int(x)), rangeslider_id="brightness") 

        
        

        #Speed Unit 
        settings.add.selector(title="Speed Unit", items=SpeedUnits, 
                          default=0, style="fancy", selector_id="SpeedUnit", align=pm.locals.ALIGN_CENTER)         
        settings.add.button(title="Update Settings", action= UpdateSettings , 
                        font_color=BLACK, background_color=GREEN, align=pm.locals.ALIGN_CENTER) 
        settings.add.button(title="Restore Defaults", action=settings.reset_value, 
                        font_color=BLACK, background_color=RED, align=pm.locals.ALIGN_CENTER) 
        settings.add.button( title="Return To Dash", action=main, 
                        font_color=BLACK, align=pm.locals.ALIGN_CENTER) 
                        
        #settings.add.button(title="Return To Dash", 
         #               action=main, align=pm.locals.ALIGN_CENTER) 
      #  settings.add.button(title="Exit Application",                   ##Temp used to exit 
      #                  action=exit, align=pm.locals.ALIGN_CENTER)                 
  

        #Using the settings 
        settingsDataStre = settings.get_input_data() 

        
        
        settings.mainloop(WIN) 
                
        
       # pygame.display.update()
       



##########
##Main loop of the program 
##########
def main():
    
    run = True
    while run:
        

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                optionsPage()
           # WarningLightCheck()
            UpdateData()
            CarGuages()
            Get_Car_Speed()
           # pygame.display.update

        
    

          
if __name__ == "__main__":
    main()




